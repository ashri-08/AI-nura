# Nura 2.0 — Foundation

Nura is evolving from a study-resource website into a student learning and productivity platform. The current foundation uses the original cream and deep-purple identity with a modern, responsive sidebar layout.

## Current working pages
- `index.html` — Overview
- `dashboard.html` — Local assignment tracker, focus timer and task progress
- `resources.html` — Resource library hub
- `Pages/` — Existing study-technique content restyled to match Nura 2.0
- `Pages/about.html` — About page, connected to the shared stylesheet

## Local data
Assignments and completed focus sessions are saved in the browser using `localStorage`. They are not synced across devices and are not accounts.

## Intentionally not in the main navigation yet
The old technique finder is being redesigned as part of a future Learning Profile. Nura AI is not linked until a real, useful interaction can be implemented.

## Run locally
Open `index.html` in a browser. For development, a local static server is recommended.


## Nura 2.1 page layout update

- `dashboard.html`: assignments and focus tools.
- `planner.html`: dedicated weekly planner.
- `goals-progress.html`: weekly study goal and progress analytics together.
- All three pages share the same local browser storage through `JS/storage.js`.


## Nura 2.2 — Learning Centre

- `learning-centre.html` provides local deck creation, manual flashcards, structured note-to-card import, flashcard review, and deck-based multiple-choice quizzes.
- Learning decks and XP are saved in browser local storage using `JS/storage.js`.
- Note import is a local formatter, not an AI model. Use one prompt/answer pair per line, separated by `:`, `->`, `=>`, or ` - `.
